import home from './scripts/views/home.js';
import './scripts/component/topbar.js';
import './scripts/component/footer-bar.js';

document.addEventListener('DOMContentLoaded', () => {
  home();
});
