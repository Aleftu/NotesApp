class MyModal extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });

        this.shadowRoot.innerHTML = `
            <style>
                .modal {
                    display: none;
                    position: fixed;
                    z-index: 1000;
                    left: 0;
                    top: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0, 0, 0, 0.5);
                    justify-content: center;
                    align-items: center;
                }

                .modal-content {
                    background: white;
                    padding: 20px;
                    border-radius: 8px;
                    min-width: 300px;
                    text-align: center;
                    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
                    position: relative;
                }

                .close-btn {
                    background: red;
                    color: white;
                    border: none;
                    padding: 10px;
                    cursor: pointer;
                    margin-top: 10px;
                }

                input, textarea {
                    width: 100%;
                    padding: 8px;
                    margin: 8px 0;
                    border: 1px solid #ccc;
                    border-radius: 4px;
                }

                .submit-btn {
                    background: green;
                    color: white;
                    padding: 10px;
                    border: none;
                    cursor: pointer;
                }
            </style>

            <div class="modal">
                <div class="modal-content">
                    <h2>Tambah Catatan</h2>
                    <form id="noteForm">
                        <input type="text" id="title" placeholder="Judul Catatan" required>
                        <textarea id="content" placeholder="Isi Catatan" required></textarea>
                        <input type="date" id="date" required>
                        <button type="submit" class="submit-btn">Simpan</button>
                        <button type="button" class="close-btn">Tutup</button>
                    </form>
                </div>
            </div>
        `;

        this.modal = this.shadowRoot.querySelector(".modal");

        this.shadowRoot.querySelector(".close-btn").addEventListener("click", () => this.close());

        this.shadowRoot.querySelector("#noteForm").addEventListener("submit", (event) => {
            event.preventDefault();
            const title = this.shadowRoot.querySelector("#title").value;
            const content = this.shadowRoot.querySelector("#content").value;
            const date = this.shadowRoot.querySelector("#date").value; // Ambil tanggal yang dipilih

            const noteContainer = document.createElement("div");
            noteContainer.classList.add("note-item");
            noteContainer.innerHTML = `
                <h3>${title}</h3>
                <p>${content}</p>
                <small>${date}</small> <!-- Menampilkan tanggal -->
            `;

            // Masukkan ke dalam #note-list
            document.querySelector("#note-list").appendChild(noteContainer);

            // Kosongkan form
            this.shadowRoot.querySelector("#title").value = "";
            this.shadowRoot.querySelector("#content").value = "";
            this.close();
        });
    }

    open() {
        const today = new Date().toISOString().split("T")[0]; 
        this.shadowRoot.querySelector("#date").value = today; 
        this.modal.style.display = "flex";
    }

    close() {
        this.modal.style.display = "none";
    }

    connectedCallback() {
        if (this.hasAttribute("open")) {
            this.open();
        }
    }
}

customElements.define("my-modal", MyModal);
