import { notesData } from "./../data/notes.js";

console.log("Data Notes:", notesData);

const notesListElement = document.querySelector("#note-items");

class NoteItem extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: "open" });
    }

    set note(note) {
        this._note = note;
        this.render();
    }

    render() {
        this.shadowRoot.innerHTML = `
        <style>
            .note-card {
                background: #fff;
                border-radius: 8px;
                padding: 16px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                display: flex;
                flex-direction: column;
                gap: 8px;
            }
            .note-card h3 {
                margin: 0;
                font-size: 1.2rem;
                color: #333;
            }
            .note-card p {
                font-size: 0.9rem;
                color: #555;
            }
            .note-footer {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-top: 10px;
            }
            button {
                padding: 6px 12px;
                border: none;
                cursor: pointer;
                border-radius: 4px;
            }
            .btn-archive {
                background: #007bff;
                color: #fff;
            }
            .btn-delete {
                background: #ff4d4d;
                color: #fff;
            }
        </style>
        <div class="note-card">
            <h3>${this._note.title}</h3>
            <p>${this._note.body}</p>
            <small>Created at: ${new Date(this._note.createdAt).toLocaleString()}</small>
            <div class="note-footer">
                <button class="btn-archive">Archive</button>
                <button class="btn-delete">🗑</button>
            </div>
        </div>
        `;
    }
}


customElements.define("note-item", NoteItem);


notesData.forEach((note) => {
    const noteElement = document.createElement("note-item");
    noteElement.note = note;
    notesListElement.appendChild(noteElement);
});
