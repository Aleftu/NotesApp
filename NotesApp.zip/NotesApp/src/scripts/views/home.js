import Notes from "./../data/notes.js";

const home = () => {
    const noteList = document.querySelector('#note-items');

    const showNotes = () => {
        displayResult(Notes);
    };

    const displayResult = (notesData) => {
        notesData.forEach((note) => {
            const notesItem = document.createElement('div'); 
            notesItem.classList.add('note-item'); 

            const titleElement = document.createElement('h3');
            titleElement.textContent = note.title;

            const bodyElement = document.createElement('p');
            bodyElement.textContent = note.body;

            const dateElement = document.createElement('small');
            dateElement.textContent = `Created at: ${new Date(note.createdAt).toLocaleString()}`;

            const statusElement = document.createElement('p');
            statusElement.textContent = `Archived: ${note.archived ? "Yes" : "No"}`;

            notesItem.append(titleElement, bodyElement, dateElement, statusElement);
            
            noteList.appendChild(notesItem);
        });
    };

    showNotes(); 
};

export default home;
