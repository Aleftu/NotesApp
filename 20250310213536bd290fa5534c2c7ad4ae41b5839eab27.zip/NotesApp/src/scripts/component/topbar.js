class TopBar extends HTMLElement {
    constructor() {
        super();

        this._shadowRoot = this.attachShadow({ mode: 'open' })

        this.shadowRoot.innerHTML = `
        <style>
            :host {
                display: block;
                width: 100%;
                background-color: #2DAA9E;
                padding: 0;
                font-family: 'Quicksand', sans-serif;
            }
            .top-bar {
                display: grid;
                place-items: center; 
                gap: 10px; 
                padding: 25px;
                width: 100%;
            }
            h1 {
                color: white;
                margin: 0;
                font-size: 1.7em;
                text-align: center;
            }
            .search-box {
                padding: 4px;
                font-size: 1em;
                border: none;
                border-radius: 5px;
                outline: none;
                width: 200px;
            }
        </style>
        <div class="top-bar">
            <h1>Notes App</h1>
            <input type="text" class="search-box" placeholder="Cari catatan...">
        </div>
        `;
    }
}

customElements.define('top-bar', TopBar);


class TitleName extends HTMLElement {
    _shadowRoot = null
    _style = null
    constructor() {
        super();

        this._shadowRoot = this.attachShadow({ mode: 'open' })
        this._style = document.createElement('style')
    }

    _updateStyle() {
        this._style.textContent = `
          :host {
            display: block;
            width: 100%;
            color: black;
            font-family: 'Quicksand',sans-serif;
          }
          div {
            padding: 24px 20px;
          }
          .title-name {
            margin: 0;
            font-size: 1.7em;
            display: grid;
            align-items: center;
            justify-content: center;
          }
        `;
    }

    _emptyContent() {
        this._shadowRoot.innerHTML = '';
    }

    connectedCallback() {
        this.render();
    }

    render() {
        this._emptyContent();
        this._updateStyle();

        this._shadowRoot.appendChild(this._style);

        const container = document.createElement('div');
        container.innerHTML = `<h3 class="title-name">NotesApp</h3>`;

        this._shadowRoot.appendChild(container);
    }

}

customElements.define('title-name', TitleName);
