import { addNote } from "../data/api.js"; 

const modal = document.querySelector(".modal");  
const openModalButton = document.querySelector("#openModal");  
const closeModalButton = document.querySelector(".closeModal");  

openModalButton.addEventListener("click", () => {
    modal.style.display = "flex"; 
});

closeModalButton.addEventListener("click", () => {
    modal.style.display = "none"; 
});document.addEventListener("DOMContentLoaded", () => {
    const openFormButton = document.querySelector("#openForm");
    const closeFormButton = document.querySelector("#closeForm");
    const noteForm = document.querySelector("#noteForm");
    const noteList = document.querySelector("#note-list");

   
    openFormButton.addEventListener("click", () => {
        noteForm.style.display = "block";
        openFormButton.style.display = "none"; 
    });

    
    closeFormButton.addEventListener("click", () => {
        noteForm.style.display = "none";
        openFormButton.style.display = "block"; 
    });

    
    noteForm.addEventListener("submit", (event) => {
        event.preventDefault(); 

        const title = document.querySelector("#title").value;
        const content = document.querySelector("#content").value;

        
        const noteItem = document.createElement("div");
        noteItem.classList.add("note-item");
        noteItem.innerHTML = `
            <h3>${title}</h3>
            <p>${content}</p>
            <small>${new Date().toLocaleDateString()}</small>
            <button class="delete-btn">Hapus</button>
        `;

        
        noteItem.querySelector(".delete-btn").addEventListener("click", () => {
            noteItem.remove();
        });

        
        noteList.appendChild(noteItem);

        
        noteForm.reset();

        
        noteForm.style.display = "none";
        openFormButton.style.display = "block"; 
    });
});



window.addEventListener("click", (event) => {
    if (event.target === modal) {
        modal.style.display = "none";
    }
});




fetch("https://notes-api.dicoding.dev/v2/notes/archived", {
    method: "GET",
    headers: { "Content-Type": "application/json" }
})
.then(response => response.json())
.then(data => console.log("Catatan diarsipkan:", data))
.catch(error => console.error("Gagal mengambil catatan arsip:", error));
