class CustomFooter extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: "open" });

        this.shadowRoot.innerHTML = `
        <style>
            :host {
                display: block;
                width: 100%;
                background-color: #2DAA9E;
                color: #fff;
                text-align: center;
                padding: 16px 0;
                font-size: 14px;
            }

            .footer-container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 0 16px;
            }

            .footer-content {
                display: flex;
                justify-content: space-between;
                align-items: center;
                flex-wrap: wrap;
            }

            .footer-left,
            .footer-right {
                margin: 8px 0;
            }

            a {
                color:rgb(27, 92, 81);
                text-decoration: none;
            }

            a:hover {
                text-decoration: underline;
            }

            @media (max-width: 768px) {
                .footer-content {
                    flex-direction: column;
                    text-align: center;
                }
            }
        </style>
        <footer>
            <div class="footer-container">
                <div class="footer-content">
                    <div class="footer-left">
                        <slot name="left">© 2025 MyWebsite. All rights reserved.</slot>
                    </div>
                    <div class="footer-right">
                        <slot name="right">Made with ❤️ by <a href="#">sipa</a></slot>
                    </div>
                </div>
            </div>
        </footer>
        `;
    }
}

customElements.define("footer-bar", CustomFooter);
