import { deleteNote, fetchNotes } from "../data/api.js";

const home = async () => {
    const noteList = document.querySelector('#note-items');

   
    try {
        const notes = await fetchNotes();
        displayResult(notes.data, noteList);
    } catch (error) {
        console.error("Gagal mengambil data:", error);
    }
};

const displayResult = (notesData, noteList) => {
    noteList.innerHTML = ""; 
    
    notesData.forEach((note) => {
        const notesItem = document.createElement('div');
        notesItem.classList.add('note-item');

        const titleElement = document.createElement('h3');
        titleElement.textContent = note.title;

        const bodyElement = document.createElement('p');
        bodyElement.textContent = note.body;

        const dateElement = document.createElement('small');
        dateElement.textContent = `Created at: ${new Date(note.createdAt).toLocaleString()}`;

        const statusElement = document.createElement('p');
        statusElement.textContent = `Archived: ${note.archived ? "Yes" : "No"}`;

       
        const buttonDelete = document.createElement('button');
        buttonDelete.classList.add('delete-btn');
        buttonDelete.style.background = "red";
        buttonDelete.style.color = "white";
        buttonDelete.style.border = "none";
        buttonDelete.style.padding = "5px 10px";
        buttonDelete.style.cursor = "pointer";
        buttonDelete.style.marginTop = "10px";
        buttonDelete.style.marginRight = "40px";

        const trashIcon = document.createElement('i');
        trashIcon.classList.add("fa-solid", "fa-trash");
        buttonDelete.append(trashIcon, document.createTextNode(" Hapus"));

       
        buttonDelete.addEventListener("click", async () => {
            const confirmDelete = confirm(`Yakin ingin menghapus "${note.title}"?`);
            if (confirmDelete) {
                try {
                    await deleteNote(note.id); 
                    notesItem.remove(); 
                    console.log(`Catatan "${note.title}" telah dihapus.`);
                } catch (error) {
                    console.error("Gagal menghapus catatan:", error);
                }
            }
        });

        
        const buttonArchive = document.createElement('button');
        buttonArchive.classList.add('archive-btn');
        buttonArchive.style.background = "blue";
        buttonArchive.style.color = "white";
        buttonArchive.style.border = "none";
        buttonArchive.style.padding = "5px 10px";
        buttonArchive.style.cursor = "pointer";
        buttonArchive.style.marginTop = "10px";
        buttonArchive.style.marginLeft = "40px";

        const archiveIcon = document.createElement('i');
        archiveIcon.classList.add("fa-solid", "fa-box-archive");
        buttonArchive.append(archiveIcon, document.createTextNode(" Arsip"));

        buttonArchive.addEventListener("click", async () => {
            const archived = confirm(`arsipkan catatan "${note.title}?"`);
        })

        notesItem.append(titleElement, bodyElement, dateElement, statusElement, buttonDelete, buttonArchive);
        noteList.appendChild(notesItem);
    });
};


document.addEventListener("DOMContentLoaded", home);

export default home;
