const BASE_URL = "https://notes-api.dicoding.dev/v2/notes";

const addNote = async (title, body) => {
    try {
        const response = await fetch(`${BASE_URL}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ title, body }),
        });
        return await response.json();
    } catch (error) {
        console.error("Gagal menambahkan catatan:", error);
    }
};

const deleteNote = async (noteId) => {
    try {
        const response = await fetch(`${BASE_URL}/${noteId}`, {
            method: "DELETE",
        });
        return await response.json();
    } catch (error) {
        console.error("Gagal menghapus catatan:", error);
    }
};

const fetchNotes = async () => {
    try {
        const response = await fetch(`${BASE_URL}`);
        return await response.json();
    } catch (error) {
        console.error("Gagal mengambil catatan:", error);
    }
};

export { addNote, deleteNote, fetchNotes };
