import home from './scripts/views/home.js';
import './scripts/component/topbar.js';
import './scripts/component/footer-bar.js';
import './style/notes.css';

document.addEventListener('DOMContentLoaded', () => {
  home();
  document.querySelector("#openModal").addEventListener("click", () => {
    document.querySelector("my-modal").open();
});
});
